import axios from 'axios';
import { OpenAIToolSet } from 'composio-core';
import config from '../../../../config/index.js';
import ApiError from '../../../errors/ApiError.js';
import { Composio } from '@composio/core';
import { GoogleGenerativeAI } from '@google/generative-ai';

const integrationId = '5c9834e1-14b3-4c06-9262-606bce538a9f';
const toolset = new OpenAIToolSet({ apiKey: config.composio.apiKey });
const composio = new Composio();

// Recursive helper to capitalize all parameter types and sanitize schemas for Gemini compatibility
const capitalizeTypes = (schema) => {
  if (!schema || typeof schema !== 'object') {
    return schema;
  }
  
  // Strip unsupported complex schema structures that fail Gemini validation
  if (schema.oneOf || schema.anyOf || schema.allOf) {
    const subSchema = schema.oneOf?.[0] || schema.anyOf?.[0] || schema.allOf?.[0];
    if (subSchema && typeof subSchema === 'object') {
      return capitalizeTypes(subSchema);
    }
  }

  const newSchema = Array.isArray(schema) ? [] : {};
  
  for (const [key, value] of Object.entries(schema)) {
    // Strip keys not supported by Gemini schemas
    if (['format', 'additionalProperties', 'anyOf', 'oneOf', 'allOf'].includes(key)) {
      continue;
    }

    if (key === 'type' && typeof value === 'string') {
      let typeVal = value.toUpperCase();
      if (typeVal === 'INT') typeVal = 'INTEGER';
      if (typeVal === 'NULL') continue; // Gemini doesn't support NULL type inside properties
      newSchema[key] = typeVal;
    } else if (typeof value === 'object') {
      newSchema[key] = capitalizeTypes(value);
    } else {
      newSchema[key] = value;
    }
  }
  
  return newSchema;
};


const getGmailIntegrationService = async () => {
  const integration = await toolset.integrations.get({
    integrationId: '32b20636-3b36-4aeb-8931-5bc614ddec45',
  });

  const inputFields = await toolset.integrations.getRequiredParams({
    integrationId: integration.id,
  });
  const data = { integration, inputFields };
  return data;
};

const authorizeGmailIntegrationService = async (userEmail) => {
  const connectionRequest = await composio.toolkits.authorize(
    userEmail,
    'gmail'
  );

  // redirect the user to the OAuth flow
  const redirectUrl = connectionRequest.redirectUrl;
  console.log('Redirect URL:', redirectUrl);
  return {
    redirectUrl,
  };
};

const sendGmailFromAuthorizedAccountService = async (body) => {
  console.log('Sending email with Composio...', body);

  // Fetch tools for your user and execute
  const userEmail = body.userEmail || '';
  const toEmail = body.toEmail;
  const subject = body.subject;
  const content = body.content;
  const toolsForResponses = await composio.tools.get(
    userEmail,
    {
      tools: ['GMAIL_SEND_EMAIL'],
      connectedAccountId: body.connectedAccountId, // Ensure you pass the connected account ID
    },
    {
      reciepient_email: 'admin@altihq.com',
    }
  );

  const task = `Send an email to ${toEmail} from ${userEmail} with the subject ${subject} and the body ${content}`;

  // Call Gemini using native @google/generative-ai
  const apiKey = config.gemini_secret_key || process.env.GEMINI_API_KEY;
  const ai = new GoogleGenerativeAI(apiKey);

  // Translate Composio OpenAI tools to Gemini function declarations
  const geminiTools = toolsForResponses.map(t => {
    const functionDecl = {
      name: t.function.name,
      description: t.function.description,
    };
    if (t.function.parameters) {
      functionDecl.parameters = capitalizeTypes(t.function.parameters);
    }
    return { functionDeclarations: [functionDecl] };
  });

  const contents = [
    {
      role: 'user',
      parts: [{ text: task }]
    }
  ];

  const modelInstance = ai.getGenerativeModel({
    model: 'gemini-3.5-flash',
    tools: geminiTools
  }, {
    systemInstruction: 'You are a helpful assistant that can help with tasks.'
  });

  const response = await modelInstance.generateContent({ contents });
  const functionCalls = response.response.functionCalls();

  if (!functionCalls || functionCalls.length === 0) {
    throw new ApiError(500, 'Gemini failed to generate Gmail send tool call');
  }

  // Map Gemini function calling responses to the mocked OpenAI completion format
  const tool_calls = functionCalls.map((call, index) => ({
    id: `call_${Date.now()}_${index}`,
    type: 'function',
    function: {
      name: call.name,
      arguments: JSON.stringify(call.args)
    }
  }));

  const mockOpenAIMsg = {
    choices: [
      {
        message: {
          role: 'assistant',
          content: null,
          tool_calls: tool_calls
        }
      }
    ]
  };

  // Execute the tool calls using mock OpenAI completions
  const result = await composio.provider.handleToolCalls(userEmail, mockOpenAIMsg, {
    connectedAccountId: body.connectedAccountId, // Ensure you pass the connected account ID
  });
  console.log(result);
  // Will return the raw response from the GMAIL_SEND_EMAIL API.
  console.log('Email sent successfully!');
};

const getAllConnectedAccountsService = async (integrationId) => {
  const connected_accounts = await composio.connectedAccounts.list({
    integrationId: 'dc88453c-0435-4487-9b61-4da031b4c2ee',
    entityId: 'default',
  });
  console.log(connected_accounts.current_page);
  return connected_accounts.items;
};

const getAllIntegrationsService = async () => {
  const allIntegrations = await toolset.integrations.list();

  // Find Gmail integration
  const gmailIntegration = allIntegrations.items.find(
    (integration) =>
      integration.name.toLowerCase().includes('gmail') ||
      integration.name.toLowerCase().includes('google mail')
  );

  console.log('Gmail Integration:', gmailIntegration);

  return {
    allIntegrations: allIntegrations.items,
    gmailIntegration,
    gmailIntegrationId: gmailIntegration?.id,
  };
};

const initiateGmailConnectionService = async (integrationId) => {
  const connectedAccount = await toolset.connectedAccounts.initiate({
    integrationId,
    entityId: 'default', // or user ID if multi-user
  });

  const data = {
    redirectUrl: connectedAccount.redirectUrl, // 🔁 Send user to this URL to authorize
    connectedAccountId: connectedAccount.connectedAccountId,
    connectionStatus: connectedAccount.connectionStatus,
  };
  return data;
};

const sendEmailService = async (req) => {
  const {
    integrationId,
    connectedAccountId,
    to,
    subject,
    message,
    isHtml = false,
  } = req.body;

  if (!connectedAccountId || !to || !subject || !message) {
    // return res.status(400).json({
    //   error:
    //     'Missing required fields: connectedAccountId, to, subject, message',
    // });
    throw new ApiError(
      400,
      'Missing required fields: connectedAccountId, to, subject, message'
    );
  }

  const actionId = 'GMAIL_SEND_EMAIL';
  const url = `https://backend.composio.dev/api/v2/actions/${actionId}/execute`;

  const response = await axios.post(
    url,
    {
      integrationId,
      connectedAccountId,
      input: {
        user_id: 'me',
        recipient_email: to,
        subject,
        body: message,
        is_html: isHtml,
      },
    },
    {
      headers: {
        'x-api-key': config.composio.apiKey,
        'Content-Type': 'application/json',
      },
    }
  );

  const data = {
    success: true,
    data: response.data,
  };
  return data;
};

// =============================
//      Youtub Services
// =============================

const youtubeIntegrationId = 'f16f5b45-f9fa-4d65-b319-e9046564edee';
const getYouTubeIntegrationService = async () => {
  const integration = await toolset.integrations.get({
    integrationId: youtubeIntegrationId,
  });

  const inputFields = await toolset.integrations.getRequiredParams({
    integrationId: integration.id,
  });

  return { integration, inputFields };
};
const initiateYouTubeConnectionService = async () => {
  const connectedAccount = await toolset.connectedAccounts.initiate({
    integrationId: youtubeIntegrationId,
    entityId: 'default',
  });

  return {
    redirectUrl: connectedAccount.redirectUrl,
    connectedAccountId: connectedAccount.connectedAccountId,
    connectionStatus: connectedAccount.connectionStatus,
  };
};

const searchYouTubeService = async (req) => {
  const { connectedAccountId, query } = req.body;

  if (!connectedAccountId || !query) {
    throw new ApiError(
      400,
      'Missing required fields: connectedAccountId, and query'
    );
  }

  const actionId = 'YOUTUBE_SEARCH_YOU_TUBE';
  const url = `https://backend.composio.dev/api/v2/actions/${actionId}/execute`;

  const response = await axios.post(
    url,
    {
      integrationId: youtubeIntegrationId,
      connectedAccountId,
      input: {
        q: query, // ✅ FIXED HERE
      },
    },
    {
      headers: {
        'x-api-key': config.composio.apiKey,
        'Content-Type': 'application/json',
      },
    }
  );

  return response.data;
};
const disconnectYouTubeAccountService = async (connectedAccountId) => {
  const response = await toolset.connectedAccounts.delete({
    connectedAccountId,
  });

  return {
    success: true,
    message: 'Disconnected successfully',
    response,
  };
};

// =============================
//      Twitter Services
// =============================

const twitterIntegrationId = '03615643-b71c-4a13-a012-4f7f94d92bc8';
const initiateTwitterConnectionService = async () => {
  const connectedAccount = await toolset.connectedAccounts.initiate({
    integrationId: twitterIntegrationId,
    entityId: 'default',
  });

  return {
    redirectUrl: connectedAccount.redirectUrl,
    connectedAccountId: connectedAccount.connectedAccountId,
    connectionStatus: connectedAccount.connectionStatus,
  };
};

const postTweetService = async (req) => {
  const { connectedAccountId, text } = req.body;

  if (!connectedAccountId || !text) {
    return { error: 'Missing required fields: connectedAccountId, text' };
  }

  const actionId = 'TWITTER_CREATION_OF_A_POST';
  const url = `https://backend.composio.dev/api/v2/actions/${actionId}/execute`;

  const response = await axios.post(
    url,
    {
      integrationId: twitterIntegrationId,
      connectedAccountId,
      input: { text },
    },
    {
      headers: {
        'x-api-key': config.composio.apiKey,
        'Content-Type': 'application/json',
      },
    }
  );

  return {
    success: true,
    data: response.data,
  };
};
const deleteTweetService = async (req) => {
  const { connectedAccountId, tweetId } = req.body;

  if (!connectedAccountId || !tweetId) {
    return { error: 'Missing required fields: connectedAccountId, tweetId' };
  }

  const actionId = 'TWITTER_POST_DELETE_BY_POST_ID';
  const url = `https://backend.composio.dev/api/v2/actions/${actionId}/execute`;

  const response = await axios.post(
    url,
    {
      integrationId: twitterIntegrationId,
      connectedAccountId,
      input: {
        post_id: tweetId,
      },
    },
    {
      headers: {
        'x-api-key': config.composio.apiKey,
        'Content-Type': 'application/json',
      },
    }
  );

  return { success: true, data: response.data };
};

const followTwitterUserService = async (req) => {
  const { connectedAccountId, username } = req.body;

  if (!connectedAccountId || !username) {
    return { error: 'Missing required fields: connectedAccountId, username' };
  }

  const actionId = 'TWITTER_FOLLOW_USER';
  const url = `https://backend.composio.dev/api/v2/actions/${actionId}/execute`;

  const response = await axios.post(
    url,
    {
      integrationId: twitterIntegrationId,
      connectedAccountId,
      input: { username },
    },
    {
      headers: {
        'x-api-key': config.composio.apiKey,
        'Content-Type': 'application/json',
      },
    }
  );

  return { success: true, data: response.data };
};
const getTwitterUserByUsernameService = async (req) => {
  const { connectedAccountId, username } = req.body;

  if (!connectedAccountId || !username) {
    return { error: 'Missing required fields: connectedAccountId, username' };
  }

  const actionId = 'TWITTER_USER_LOOKUP_BY_USERNAMES';
  const url = `https://backend.composio.dev/api/v2/actions/${actionId}/execute`;

  const response = await axios.post(
    url,
    {
      integrationId: twitterIntegrationId,
      connectedAccountId,
      input: { usernames: [username] }, // note: array of usernames expected
    },
    {
      headers: {
        'x-api-key': config.composio.apiKey,
        'Content-Type': 'application/json',
      },
    }
  );

  return { success: true, data: response.data };
};

const getUserIdFromUsername = async (connectedAccountId, username) => {
  const actionId = 'TWITTER_USER_LOOKUP_BY_USERNAMES';
  const url = `https://backend.composio.dev/api/v2/actions/${actionId}/execute`;

  const response = await axios.post(
    url,
    {
      integrationId: twitterIntegrationId,
      connectedAccountId,
      input: { usernames: [username] },
    },
    {
      headers: {
        'x-api-key': config.composio.apiKey,
        'Content-Type': 'application/json',
      },
    }
  );
  console.log(
    'Response from Twitter API:',
    JSON.stringify(response.data, null, 2)
  );

  const users = response.data.data.data;
  if (users && users.length > 0) {
    return users[0].id;
  }
  throw new Error('User not found');
};

// Step 2: Send DM by user ID (participant_id)
const sendDMByUsernameService = async (req) => {
  const { connectedAccountId, username, text } = req.body;

  if (!connectedAccountId || !username || !text) {
    return {
      error: 'Missing required fields: connectedAccountId, username, text',
    };
  }

  try {
    const participant_id = await getUserIdFromUsername(
      connectedAccountId,
      username
    );

    const actionId = 'TWITTER_SEND_A_NEW_MESSAGE_TO_A_USER';
    const url = `https://backend.composio.dev/api/v2/actions/${actionId}/execute`;

    const response = await axios.post(
      url,
      {
        integrationId: twitterIntegrationId,
        connectedAccountId,
        input: {
          participant_id, // Use participant_id instead of target_user_id
          text,
        },
      },
      {
        headers: {
          'x-api-key': config.composio.apiKey,
          'Content-Type': 'application/json',
        },
      }
    );

    return { success: true, data: response.data };
  } catch (error) {
    return { error: error.message };
  }
};
// =============================
//      LinkedIn Services
// =============================

const getLinkedInOAuthRedirectUrlService = async (integrationId, entityId) => {
  const connectedAccount = await toolset.connectedAccounts.initiate({
    integrationId,
    entityId,
  });
  return connectedAccount.redirectUrl;
};

const exchangeCodeLinkedInService = async (code, integrationId, entityId) => {
  const connectedAccount = await toolset.connectedAccounts.exchangeCode({
    code,
    integrationId,
    entityId,
  });
  return connectedAccount;
};

const postToLinkedInService = async (
  integrationId,
  connectedAccountId,
  content
) => {
  const integration = await toolset.integrations.get({
    integrationId: 'ff2c1c00-03ca-4135-9fe7-afa775098c26',
  });
  const expectedInputFields = await toolset.integrations.getRequiredParams(
    integration.id
  );
  // Collect auth params from your users

  console.log(expectedInputFields);
  return expectedInputFields;
};

// =============================
//   Google Calender Services
// =============================

const calendarIntegrationId = '21c69c18-54ef-464b-a181-dc82f3e5b089';
const initiateGoogleCalendarConnectionService = async () => {
  const connectedAccount = await toolset.connectedAccounts.initiate({
    integrationId: calendarIntegrationId,
    entityId: 'default',
  });

  return {
    redirectUrl: connectedAccount.redirectUrl,
    connectedAccountId: connectedAccount.connectedAccountId,
    connectionStatus: connectedAccount.connectionStatus,
  };
};
const createCalendarEventService = async (req) => {
  const {
    connectedAccountId,
    summary,
    description,
    startTime,
    endTime,
    timezone = 'Asia/Dhaka',
  } = req.body;

  if (!connectedAccountId || !summary || !startTime || !endTime) {
    return {
      error:
        'Missing required fields: connectedAccountId, summary, startTime, endTime',
    };
  }

  const actionId = 'GOOGLECALENDAR_CREATE_EVENT';
  const url = `https://backend.composio.dev/api/v2/actions/${actionId}/execute`;

  const response = await axios.post(
    url,
    {
      integrationId: calendarIntegrationId,
      connectedAccountId,
      input: {
        summary,
        description,
        start_datetime: startTime,
        end_datetime: endTime,
        timezone,
      },
    },
    {
      headers: {
        'x-api-key': config.composio.apiKey,
        'Content-Type': 'application/json',
      },
    }
  );

  return {
    success: true,
    data: response.data,
  };
};

const getCalendarEventsService = async (req) => {
  const { connectedAccountId } = req.body;

  if (!connectedAccountId) {
    return { error: 'Missing required field: connectedAccountId' };
  }

  const actionId = 'GOOGLECALENDAR_EVENTS_LIST';
  const url = `https://backend.composio.dev/api/v2/actions/${actionId}/execute`;

  const response = await axios.post(
    url,
    {
      integrationId: calendarIntegrationId,
      connectedAccountId,
      input: {
        calendarId: 'primary', // Use 'primary' for main calendar
      },
    },
    {
      headers: {
        'x-api-key': config.composio.apiKey,
        'Content-Type': 'application/json',
      },
    }
  );

  return response.data;
};
const deleteCalendarEventService = async (req) => {
  const { connectedAccountId, eventId, calendarId = 'primary' } = req.body;

  if (!connectedAccountId || !eventId) {
    return {
      error: 'Missing required fields: connectedAccountId, eventId',
    };
  }

  const actionId = 'GOOGLECALENDAR_DELETE_EVENT';
  const url = `https://backend.composio.dev/api/v2/actions/${actionId}/execute`;

  const response = await axios.post(
    url,
    {
      integrationId: calendarIntegrationId,
      connectedAccountId,
      input: {
        event_id: eventId,
        calendar_id: calendarId,
      },
    },
    {
      headers: {
        'x-api-key': config.composio.apiKey,
        'Content-Type': 'application/json',
      },
    }
  );

  return response.data;
};
const updateCalendarEventService = async (req) => {
  const {
    connectedAccountId,
    eventId,
    calendarId = 'primary',
    summary,
    description,
    startTime,
    endTime,
    timezone = 'Asia/Dhaka',
  } = req.body;

  if (!connectedAccountId || !eventId) {
    return { error: 'Missing required fields: connectedAccountId, eventId' };
  }

  const actionId = 'GOOGLECALENDAR_PATCH_EVENT';
  const url = `https://backend.composio.dev/api/v2/actions/${actionId}/execute`;

  const response = await axios.post(
    url,
    {
      integrationId: calendarIntegrationId,
      connectedAccountId,
      input: {
        calendar_id: calendarId,
        event_id: eventId,
        summary, // optional
        description, // optional
        start_time: startTime, // optional
        end_time: endTime, // optional
        timezone, // optional
      },
    },
    {
      headers: {
        'x-api-key': config.composio.apiKey,
        'Content-Type': 'application/json',
      },
    }
  );

  return response.data;
};

// =============================
//      GItHub Services
// =============================

const githubIntegrationId = '394bc42b-5fa8-4777-8e08-6fed12510deb';

const getGithubIntegrationService = async () => {
  const integration = await toolset.integrations.get({
    integrationId: githubIntegrationId,
  });

  const inputFields = await toolset.integrations.getRequiredParams({
    integrationId: integration.id,
  });

  return { integration, inputFields };
};

const initiateGithubConnectionService = async (integrationId) => {
  const connectedAccount = await toolset.connectedAccounts.initiate({
    integrationId,
    entityId: 'default',
  });

  return {
    redirectUrl: connectedAccount.redirectUrl,
    connectedAccountId: connectedAccount.connectedAccountId,
    connectionStatus: connectedAccount.connectionStatus,
  };
};
const createGithubIssueService = async (req) => {
  const { connectedAccountId, owner, repo, title, body } = req.body;

  if (!connectedAccountId || !owner || !repo || !title) {
    return { error: 'Missing required fields' };
  }

  const actionId = 'GITHUB_CREATE_ISSUE';
  const url = `https://backend.composio.dev/api/v2/actions/${actionId}/execute`;

  const response = await axios.post(
    url,
    {
      integrationId: githubIntegrationId,
      connectedAccountId,
      input: {
        owner,
        repo,
        title,
        body,
      },
    },
    {
      headers: {
        'x-api-key': config.composio.apiKey,
        'Content-Type': 'application/json',
      },
    }
  );

  return response.data;
};
// =============================
//      Amazon Services
// =============================
const initiateAmazonConnectionService = async () => {
  // 1. Get all integrations
  const allIntegrationsResponse = await toolset.integrations.list();
  const integrations = allIntegrationsResponse.items || [];

  // 2. Find Amazon integration
  const amazonIntegration = integrations.find((integration) =>
    integration.name.toLowerCase().includes('amazon')
  );

  if (!amazonIntegration) {
    throw new Error('Amazon integration not found');
  }

  // 3. Initiate OAuth connection
  const connectionRequest = await toolset.connectedAccounts.initiate({
    integrationId: amazonIntegration.id,
    entityId: 'default', // Change as needed, "default" works for testing
  });

  return {
    redirectUrl: connectionRequest.redirectUrl,
    connectedAccountId: connectionRequest.connectedAccountId,
    connectionStatus: connectionRequest.connectionStatus,
  };
};

// const searchAmazonProductService = async req => {
//   const { connectedAccountId, query } = req.body;

//   if (!connectedAccountId || !query) {
//     return { error: 'Missing required fields: connectedAccountId, query' };
//   }

//   const actionId = 'AMAZON_SEARCH_PRODUCT';
//   const url = `https://backend.composio.dev/api/v2/actions/${actionId}/execute`;

//   const response = await axios.post(
//     url,
//     {
//       integrationId: amazonIntegrationId, // Replace with your ID
//       connectedAccountId,
//       input: { query },
//     },
//     {
//       headers: {
//         'x-api-key': config.composio.apiKey,
//         'Content-Type': 'application/json',
//       },
//     },
//   );

//   return response.data;
// };

export const composioService = {
  getGmailIntegrationService,
  initiateGmailConnectionService,
  sendEmailService,
  getYouTubeIntegrationService,
  initiateYouTubeConnectionService,
  searchYouTubeService,
  disconnectYouTubeAccountService,
  getLinkedInOAuthRedirectUrlService,
  exchangeCodeLinkedInService,
  postToLinkedInService,
  initiateGoogleCalendarConnectionService,
  createCalendarEventService,
  getCalendarEventsService,
  deleteCalendarEventService,
  updateCalendarEventService,
  getGithubIntegrationService,
  initiateGithubConnectionService,
  createGithubIssueService,
  initiateAmazonConnectionService,
  // searchAmazonProductService,
  initiateTwitterConnectionService,
  postTweetService,
  deleteTweetService,
  followTwitterUserService,
  getTwitterUserByUsernameService,
  sendDMByUsernameService,
  getAllIntegrationsService,
  authorizeGmailIntegrationService,
  sendGmailFromAuthorizedAccountService,
  getAllConnectedAccountsService,
};
