import { startDailyUsageResetCron } from './subscription/resetDailyUsage.js';
import { startStripeSyncCron } from './subscription/syncStripeSubscriptions.js';
import { initializeTenantCronJobs } from './tenant/resetUsage.js';
import { startWorkspaceCleanupCron } from './docker/workspaceCleanup.js';
import { logger } from '../../shared/logger.js';

/**
 * Initialize all cron jobs
 * Call this function from the main application entry point
 */
export const initializeCronJobs = () => {
  logger.info('Initializing cron jobs...');

  try {
    // Start daily usage reset (runs at midnight UTC)
    startDailyUsageResetCron();

    // Start Stripe sync (runs every hour)
    startStripeSyncCron();

    // Initialize tenant-related cron jobs (monthly reset, trial cleanup, usage warnings)
    initializeTenantCronJobs();

    // Start Docker Workspace idle auditing cleanup (runs every 5 minutes)
    startWorkspaceCleanupCron();

    logger.info('All cron jobs initialized successfully');
  } catch (error) {
    logger.error('Error initializing cron jobs:', error);
  }
};

export default {
  initializeCronJobs,
};
